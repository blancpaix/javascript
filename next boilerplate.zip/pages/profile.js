import React from 'react';

const Profile = () => {
  const nullData = null;

  return (
    <div>Profile Page</div>
  );
};

export default Profile;
