import React from 'react';
import { useSelector } from 'react-redux';
import AppLayout from '../components/AppLayout';

const Home = () => {
  const { me } = useSelector((state) => state.user);

  return (
    <AppLayout>
      <div>Index Page</div>
      <div>{me}</div>
    </AppLayout>

  );
};

export default Home;
