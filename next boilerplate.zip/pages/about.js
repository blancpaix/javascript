import React from 'react';

const About = () => {
  const nullData = null;

  return (
    <div>About Page</div>
  );
};

export default About;
