import React from 'react';

const Signup = () => {
  const nullData = null;

  return (
    <div>Signup Page</div>
  );
};

export default Signup;
