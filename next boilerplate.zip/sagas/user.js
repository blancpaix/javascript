import axios from 'axios';
import { all, call, fork, put, throttle } from 'redux-saga/effects';
import { SIGNUP_REQUEST, SIGNUP_SUCCESS, SIGNUP_FAILURE } from '../reducers/user';

function signupAPI(data) {
  return axios.post('/user', data);
}
function* signup(action) {
  try {
    const result = yield call(signupAPI, action.data);
    yield put({
      type: SIGNUP_SUCCESS,
      data: result.data,
    });
  } catch (err) {
    yield put({
      type: SIGNUP_FAILURE,
      error: err.response.error,
    });
  }
}

function* watchSignup() {
  yield throttle(3000, SIGNUP_REQUEST, signup);
}

export default function* userSaga() {
  yield all([
    fork(watchSignup),
  ]);
}
