import axios from 'axios';
import { all, fork } from 'redux-saga/effects';

import userSaga from './user';

axios.defaults.baseURL = 'http://localhost:3000';
axios.defaults.withCredentials = true;

export default function* indexSaga() {
  yield all([
    fork(userSaga),
    // fork(postSaga),
  ]);
}
